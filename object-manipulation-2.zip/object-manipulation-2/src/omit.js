/* exported omit */
function omit(source, keys) {
  var object = source;
  console.log(object)

  for(var i = 0; i<keys.length; i++) {
    console.log(keys[i])
    delete object[keys[i]]
  }
  console.log(object)
return object;
}
