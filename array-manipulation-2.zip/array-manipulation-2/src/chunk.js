/* exported chunk */
function chunk(array, count) {
  // var newArray = []

  // if(array.length===0) {
  //   return newArray
  // }

  // console.log(array.length / count)

  // for(var i = 0; i<(array.length / count);i++){
  //   newArray.push([])
  //   for(var j = 0; j<count;j++){
  //     if(array.length===(j+1)*count+1) {
  //       console.log('j+k '+(j+1)*count+1)
  //     } else {
  //       newArray[i].push([])
  //     }
  //   }
  // }

  // var j = 0
  // var k = 0

  // for(var i = 0; i<array.length; i++){
  //   console.log(j+' '+k+' '+array[i])
  //   newArray[j][k] = array[i]
  //   k++;
  //   if(k===count){
  //     k = 0
  //     j++;
  //   }
  // }
  // console.log(newArray)
  // return newArray
}
